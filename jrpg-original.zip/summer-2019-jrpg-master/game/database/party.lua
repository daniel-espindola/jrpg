
return {
  'fighter', 'fighter', 'fighter', 'fighter'
}

