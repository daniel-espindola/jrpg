
return {
  'slime', 'slime'
}

