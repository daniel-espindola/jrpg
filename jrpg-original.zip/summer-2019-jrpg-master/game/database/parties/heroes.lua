
return {
  'fighter', 'ranger', 'wizard', 'vampire'
}

