
return {
  sprite = 'female-vampire',
}

