
return {
  sprite = 'slime',
}

