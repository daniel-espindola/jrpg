
return {
  sprite = 'wizard-face',
}

