
return {
  sprite = 'woman-elf-face',
}

