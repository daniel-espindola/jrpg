
return {
  sprite = 'brutal-helm',
}

