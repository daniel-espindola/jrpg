
function love.conf(t)
  t.window.title = "JRPG"
  t.window.width = 1280
  t.window.height = 720
end


