

### BRAINSTORM

- Mecanica de armadura, ela funciona como "vida extra" que é reduzida primeiro antes da vida de um heroi
- Mecanica de charge: ataques mais fortes que precisam ficar X turnos carregando com a personagem idle até ativa-lo
- Mecanica (complicada) de Quick Time Event Attacks: estilo paper mario, alguns ataques podem triggerar algum quick time event que dado um input com um bom timing causa algum bonus no ataque (ou se voce errar, o ataque so falha).
- Inimigos bomba-relogio, que ficam X turnos sem fazer nada, e depois explodem, dando muito dano em todos herois. Voce precisa mata-los rapidamente.
- Inimigos espinhosos, que se recebem dano fisico, retornam parte do dano no heroi que o atacou.
- Inimigos suporte, que so ficam bufando e curando outros inimigos.
- Inimigos que summonam outros inimigos
- Magias/poderes que afetam mais de um personagem (precisa implementar a seleçao de um grupo de personagens)
- Implementar sistema de fraquezas/super efetividade, como por exemplo ataques de agua dao mais dano em inimigos de fogo, etc.
- Poder de reviver aliados mortos
- Mecanica de fugir da batalha